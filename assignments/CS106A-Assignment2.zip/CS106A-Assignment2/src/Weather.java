// TODO: comment this program

import acm.program.*;

public class Weather extends ConsoleProgram {
	public void run() {
		// TODO: finish this program
	}
}

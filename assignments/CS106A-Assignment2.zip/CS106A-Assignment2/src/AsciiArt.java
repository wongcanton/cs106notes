import acm.program.*;

public class AsciiArt extends ConsoleProgram {
	public void run() {
		// TODO: finish this program
	}
}

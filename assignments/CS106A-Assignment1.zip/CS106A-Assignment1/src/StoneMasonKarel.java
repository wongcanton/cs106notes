/*
 * TODO: comment this program
 */

import stanford.karel.*;

public class StoneMasonKarel extends SuperKarel {
	
	// TODO: write the code to implement this program

}

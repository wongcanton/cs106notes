/*
 * TODO: comment this program
 */

import stanford.karel.*;

public class CollectNewspaperKarel extends SuperKarel {
	
	// TODO: write the code to implement this program

}
